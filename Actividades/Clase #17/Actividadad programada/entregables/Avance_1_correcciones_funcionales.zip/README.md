﻿# Avance 1 — Correcciones esenciales

Estado funcional inicial: corrige JSON/localStorage, endpoint, manejo asíncrono, bloqueo de controles y respaldo sin Internet.

Para ejecutar, abrir `index.html` con Live Server. Para registrar este avance, copiar estos archivos a la carpeta del proyecto y hacer el primer commit.

Commit sugerido: `fix: corregir memoria y flujo asincrono del chat`
