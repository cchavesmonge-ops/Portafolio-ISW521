﻿const KEY = "memoria_llm";
const ENDPOINT = "https://jsonplaceholder.typicode.com/posts";
const chat = document.getElementById("chat");
const form = document.getElementById("formChat");
const input = document.getElementById("entrada");
const status = document.getElementById("estado");
const button = document.getElementById("btnEnviar");
let history = loadHistory();
history.forEach(({ rol, texto }) => renderMessage(rol, texto));
if (history.length) status.textContent = `Memoria restaurada: ${history.length} mensajes`;

function loadHistory() {
  try {
    const stored = localStorage.getItem(KEY);
    if (stored === null) return [];
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) throw new TypeError("Historial inválido");
    return parsed.filter(item => item && ["user", "ia"].includes(item.rol) && typeof item.texto === "string");
  } catch (error) {
    console.warn("Se descartó una memoria inválida.", error);
    localStorage.removeItem(KEY);
    return [];
  }
}

function saveHistory() { localStorage.setItem(KEY, JSON.stringify(history)); }
function renderMessage(role, text) {
  const element = document.createElement("div");
  element.className = `msg ${role}`;
  element.textContent = text;
  chat.appendChild(element);
  chat.scrollTop = chat.scrollHeight;
}
function addMessage(role, text) {
  history.push({ rol: role, texto: text });
  saveHistory();
  renderMessage(role, text);
}
function localReply(text) {
  if (/^(hola|buenas)/i.test(text)) return "¡Hola! ¿En qué puedo ayudarte hoy?";
  return `Recibí tu mensaje: “${text}”. El servicio remoto no está disponible temporalmente.`;
}
async function getReply(text) {
  try {
    const index = (history.length % 100) + 1;
    const response = await fetch(`${ENDPOINT}/${index}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!data.title) throw new Error("Respuesta sin título");
    return `🤖 ${data.title}`;
  } catch (error) {
    console.warn("Se usará la respuesta local.", error);
    return localReply(text);
  }
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text || button.disabled) return;
  addMessage("user", text);
  input.value = "";
  status.textContent = "Pensando...";
  button.disabled = input.disabled = true;
  try {
    addMessage("ia", await getReply(text));
    status.textContent = "✓ Respuesta recibida";
  } finally {
    button.disabled = input.disabled = false;
    input.focus();
  }
});
