﻿# Cómo aplicar este avance

Este ZIP es el segundo estado completo. Aplicarlo después de haber confirmado el Avance 1: reemplazar `index.html` y `css`, eliminar `app.js`, y copiar el resto del contenido. La eliminación de `app.js` aparecerá correctamente en Git junto con la nueva arquitectura modular.

Commit sugerido: `refactor: aplicar arquitectura hexagonal y agregar pruebas`
